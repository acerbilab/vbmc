clear;clc

%  For probability estimates, you need '-b 1' for training and testing:

 load heart_scale.mat
 model = svmtrain(heart_scale_label, heart_scale_inst, '-c 1 -g 0.07 -b 1');
 load heart_scale.mat
 [predict_label, accuracy, prob_estimates] = svmpredict(heart_scale_label, heart_scale_inst, model, '-b 1');

 
% Take linear kernel for example, the following precomputed kernel example 
% gives exactly same training error as LIBSVM built-in linear kernel

 load heart_scale.mat
 n = size(heart_scale_inst,1);
 K = heart_scale_inst*heart_scale_inst';
 K1 = [(1:n)', K];
 model = svmtrain(heart_scale_label, K1, '-t 4');
 [predict_label, accuracy, dec_values] = svmpredict(heart_scale_label, K1, model);
clear;clc

load heart_scale.mat
 model = svmtrain(heart_scale_label, heart_scale_inst, '-c 1 -g 0.07');
 [predict_label, accuracy, dec_values] = svmpredict(heart_scale_label, heart_scale_inst, model); % test the training data
load heart_scale.mat
 model = svmtrain(heart_scale_label, heart_scale_inst, '-c 1 -g 0.07 -b 1');
 load heart_scale.mat
 n = size(heart_scale_inst,1);
 
% To use precomputed kernel, you must include sample serial number as
% the first column of the training and testing data (assume your kernel
% matrix is K, # of instances is n):

 K1 = [(1:n)', K]; % include sample serial number as first column
 model = svmtrain(label_vector, K1, '-t 4');
 [predict_label, accuracy, dec_values] = svmpredict(label_vector, K1, model); % test the training data

required_options = {'plate', 'mjd', 'fiber'};
check_required_options;

if (options_defined)

  % below we subsample the data to every skip'th point
  skip = 20;

  % base directory where spectra are stored
  data_directory = '~/work/data/sdss/raw/';

  filename = @(plate, mjd, fiber) ...
             ([data_directory ...
               num2str(plate) '/spec-' ...
               num2str(plate) '-' ...
               num2str(mjd)   '-' ...
               num2str(fiber, '%04i') '.fits']);

  % this tends to work better but is faster and lamer, try if you'd like

  % inference_method              = @infLaplace;
  % likelihood                    = @likT;
  % continuum_hyperparameters.lik = nan(2, 1);
  % hyperparameter_inds           = 1:5;

  hyperparameter_inds            = [1:2 4:5];
  
  inference_method               = @infEP;
  likelihood                     = @likLaplace;
  continuum_hyperparameters.lik  = nan;
  total_hyperparameters.lik      = continuum_hyperparameters.lik;

  continuum_mean_function        = {@meanConst};
  continuum_hyperparameters.mean = nan;
  dla_mean_function              = {@meanScale, {@meanDrift, {@meanVoightProfile}}};
  total_mean_function            = {@meanSum, {continuum_mean_function, dla_mean_function}};
  total_hyperparameters.mean     = nan(4, 1);
  
  continuum_covariance_function  = {@covMaterniso, 3};
  continuum_hyperparameters.cov  = nan(2, 1);
  dla_covariance_function        = {@covDrift, {@covMaterniso, 3}};
  total_covariance_function      = {@covSum, {continuum_covariance_function, dla_covariance_function}};
  total_hyperparameters.cov      = nan(6, 1);  
  
  [wavelengths, flux, noise_variance, redshift, is_quasar] = ...
      read_fits_data(filename(plate, mjd, fiber), false);

  if (is_quasar)

    test_x  = wavelengths;
    train_x = wavelengths(1:skip:end);
    train_y = flux(1:skip:end);

    continuum_likelihood = @(sample) ...
        -gp_likelihood(rewrap(continuum_hyperparameters, sample), ...
                       inference_method, continuum_mean_function, ...
                       continuum_covariance_function, likelihood, ...
                       train_x, train_y);

    continuum_prior = @(sample) ...
        -sum(arrayfun(@(i) normlike([mle_means(i), mle_stds(i)], ...
                                    sample(i), hyperparameter_inds)));
    
    continuum_hyperparameters = rewrap(continuum_hyperparameters, ...
            mle_means(hyperparameter_inds));
    [continuum_mle_hyperparameters, continuum_mle_probability] = ...
        minimize(continuum_hyperparameters, @gp_likelihood, 20, ...
                 inference_method, continuum_mean_function, ...
                 continuum_covariance_function, likelihood, train_x, train_y);
        
    fprintf('mle log likelihood (no dla): %f\n', -continuum_mle_probability(end));
  
    continuum_mle_point = unwrap(continuum_mle_hyperparameters);

    [~, ~, continuum_mle_mean, continuum_mle_variance] = ...
        gp_test(continuum_mle_hyperparameters, inference_method, ...
                continuum_mean_function, continuum_covariance_function, ...
                likelihood, train_x, train_y, test_x);
    
    continuum_mle_mean_value = @(x) interp1(test_x, continuum_mle_mean, x);

    maximum_dla_location = convert_z(redshift);

    dla_log_prior = ...
        @(sample) ...
        log(interp1(central_wavelength_difference_prior_x, ...
                    central_wavelength_difference_prior_p, ...
                    maximum_dla_location - sample(1))) + ...
        -normlike([dla_width_prior_mean, dla_width_prior_std], ...
                  sample(2));
  
    dla_log_likelihood = @(sample) -gp_likelihood( ...
        rewrap(total_hyperparameters, sample), inference_method, ...
        total_mean_function, total_covariance_function, likelihood, ...
        train_x, train_y);
  else
    fprintf('the selected data are not observations of a quasar!\n');
  end
end